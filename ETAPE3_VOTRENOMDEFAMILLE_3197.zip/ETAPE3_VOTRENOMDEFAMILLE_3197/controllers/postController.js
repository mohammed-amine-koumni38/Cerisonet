const { isValidObjectId } = require('mongoose');
const Post = require('../models/postModel');
const mongoose = require('mongoose');

const createPostController = (pool) => {
  const getPosts = async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ success: false, message: 'Non connecte.' });
    }

    try {
      const limit = parseInt(req.query.limit) || 10;
      let cursor = req.query.cursor; // Fixing the malformed cursor line

      let query = {};

      if (cursor) {
        if (!mongoose.Types.ObjectId.isValid(cursor)) {
          return res.status(400).json({ success: false, message: 'Cursor invalide.' });
        }

        query._id = { $lt: new mongoose.Types.ObjectId(cursor) };
      }
      const posts = await Post.find(query)
        .sort({ _id: -1 })
        .limit(limit)
        .lean();

      // Phase A: collect unique author ids from posts and comments.
      const setAuthors = new Set();
      for (const post of posts) {
        if (post.createdBy !== undefined && post.createdBy !== null) {
          setAuthors.add(post.createdBy);
        }

        for (const comment of (post.comments || [])) {
          if (comment.commentedBy !== undefined && comment.commentedBy !== null) {
            setAuthors.add(comment.commentedBy);
          }
        }
      }

      // Phase B: fetch all SQL authors in one query.
      const authorIds = Array.from(setAuthors);
      const usersResult = authorIds.length > 0
        ? await pool.query(
          'SELECT id, nom, prenom, pseudo FROM fredouil.compte WHERE id = ANY($1::int[])',
          [authorIds]
        )
        : { rows: [] };

      // Phase C: map authors and enrich posts/comments for response.
      const userMap = new Map(usersResult.rows.map((user) => [user.id, user]));

      const returnedPosts = posts.map((post) => ({
        ...post,
        user: userMap.get(post.createdBy) || null,
        comments: (post.comments || []).map((comment) => ({
          ...comment,
          user: userMap.get(comment.commentedBy) || null
        }))
      }));

      return res.json({ success: true, posts: returnedPosts, user: req.session.user });
    } catch (err) {
      console.error('Erreur GET /posts :', err);
      return res.status(500).json({ success: false, message: 'Erreur serveur.' });
    }
  };

  const createPost = async (req, res) => {
    if (!req.session.user) {
      return res.status(401).json({ success: false, message: 'Non connecte.' });
    }

    const { body, image, hashtags, shared } = req.body;
    if (!body || !String(body).trim()) {
      return res.status(400).json({ success: false, message: 'Le texte du post est obligatoire.' });
    }

    const now = new Date();
    const payload = {
      date: now.toLocaleDateString('fr-FR'),
      hour: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }),
      body: String(body).trim(),
      createdBy: req.session.user.id,
      image: {
        url: image?.url || '',
        title: image?.title || ''
      },
      hashtags: Array.isArray(hashtags) ? hashtags : [],
      shared: shared || null
    };

    try {
      const createdPost = await Post.create(payload);
      return res.status(201).json({ success: true, post: createdPost });
    } catch (err) {
      console.error('Erreur POST /posts :', err);
      return res.status(500).json({ success: false, message: 'Erreur serveur.' });
    }
  };
  
//   let cursor = null;
//   const loadPost= async (req,res)=>{
//      let url = `/posts?limit=10`;

//      if (cursor) {
//        url += `&cursor=${cursor}`;
//      }

//       const res = await fetch(url);
//       const data = await res.json();

//       console.log(data.data);

//       cursor = data.nextCursor;
// }
  

  return {
    getPosts,
    createPost
  };
};

module.exports = createPostController;
