# ETAPE 3 - CeriSoNet

Ce repertoire contient la livraison autonome de l'etape 3:
- serveur Node.js (fichiers .js necessaires)
- distribution Angular compilee (index.html + fichiers JS/CSS)
- certificats HTTPS (certs/key.pem et certs/cert.pem)

## Lancement

1. Installer les dependances:

```bash
npm install
```

2. Demarrer le serveur HTTPS:

```bash
node monserver.js
```

Le serveur sert les fichiers statiques Angular depuis `./` (racine de ce repertoire).

## Modules utilises

Dependances serveur:
- express
- pg
- mongoose
- express-session
- connect-mongodb-session
- dotenv
- bcryptjs

Module additionnel par rapport au minimum vu en cours:
- bcryptjs

## Variables d'environnement

Le fichier `.env` est fourni dans ce repertoire.
