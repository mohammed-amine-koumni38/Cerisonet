const express = require('express');
const createPostController = require('../controllers/postController');

const createPostRouter = (pool) => {
  const router = express.Router();
  const { getPosts, createPost } = createPostController(pool);

  router.get('/getPosts', getPosts);
  router.post('/createPost', createPost);

  return router;
};

module.exports = createPostRouter;
