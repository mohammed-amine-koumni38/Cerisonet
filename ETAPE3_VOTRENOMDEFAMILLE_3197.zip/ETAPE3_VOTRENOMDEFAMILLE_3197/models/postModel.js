const mongoose = require('mongoose');

const commentSchema = mongoose.Schema(
  {
    text: {
      type: String,
      required: true,
      trim: true
    },
    commentedBy: {
      type: Number,
      required: true
    },
    date: {
      type: String,
      required: true
    },
    hour: {
      type: String,
      required: true
    }
  },
  { _id: false }
);

const postSchema = mongoose.Schema({
  date: {
    type: String,
    required: true
  },
  hour: {
    type: String,
    required: true
  },
  body: {
    type: String,
    required: true,
    trim: true
  },
  createdBy: {
    type: Number,
    required: true
  },
  image: {
    url: {
      type: String,
      default: ''
    },
    title: {
      type: String,
      default: ''
    }
  },
  likes: {
    type: Number,
    default: 0
  },
  hashtags: {
    type: [String],
    default: []
  },
  comments: {
    type: [commentSchema],
    default: []
  },
  shared: {
    type: mongoose.SchemaTypes.ObjectId,
    ref: 'Post',
    default: null
  }
}, {
  collection: 'CERISoNet'
});

const Post = mongoose.model('Post', postSchema);

module.exports = Post;
